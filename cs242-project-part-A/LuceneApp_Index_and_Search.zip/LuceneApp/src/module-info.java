module LuceneApp {
	requires lucene.core;
	requires jdk.scripting.nashorn;
}